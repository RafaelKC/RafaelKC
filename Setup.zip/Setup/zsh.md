* sudo apt install zsh;
* instalar de <https://ohmyz.sh/>
* instalar de <https://github.com/zsh-users/zsh-autosuggestions>

\* git config --global init.defaultBranch main
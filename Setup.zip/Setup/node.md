* clone <https://github.com/lukechilds/zsh-nvm>

\* source ./zsh-nvm/zsh-nvm.plugin.zsh

\* npm i gitignore
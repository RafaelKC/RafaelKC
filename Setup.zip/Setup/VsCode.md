
### Extension

#### Geral

* **Auto Close Tag**
* **Auto Import;**
* **Auto Rename Tag**
* **Code Spell Checker**
* **Portuguese - Code Spell Checker**
* **Color Highlight**
* **Bracket Pair Colorizer 2**
* **Prettier - Code formatter**
* **ESLint**
* **TSLint**
* **EditorConfig for VS Code**
* **Live Server**
* **npm**
* **GitLens — Git supercharged**
* **Path Intellisense**
* **Prisma**
* **TypeScript Hero**
* **vscode-styled-components**
* **Docker**
* **WSL**
* **DotEnv**

  #### Angular
* **Angular Language Service;**
* **Angular-Cli**
* **Angular Material 2, Flex layout 1, Covalent 1 & Material icon snippets**

#### React

* **Rocketseat React Native**
* **Rocketseat ReactJS**
* **React Native Tools**
* **Typescript React code snippets**
* **Styled-components**

#### Theme

* **Monokai Pro**
* **Material Icon Theme**

### Configs

* Fonte FireCode